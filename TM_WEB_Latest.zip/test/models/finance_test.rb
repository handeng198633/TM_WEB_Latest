require 'test_helper'

class FinanceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
