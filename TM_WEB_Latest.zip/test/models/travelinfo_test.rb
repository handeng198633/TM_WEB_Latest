require 'test_helper'

class TravelinfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
