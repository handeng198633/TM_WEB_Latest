require 'test_helper'

class TrainTicketTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
