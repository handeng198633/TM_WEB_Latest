require 'test_helper'

class PlaneticketTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
