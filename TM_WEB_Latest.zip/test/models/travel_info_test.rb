require 'test_helper'

class TravelInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
