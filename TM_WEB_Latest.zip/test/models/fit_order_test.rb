require 'test_helper'

class FitOrderTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
