require 'test_helper'

class PlaneTicketTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
