require 'test_helper'

class ReturninfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
