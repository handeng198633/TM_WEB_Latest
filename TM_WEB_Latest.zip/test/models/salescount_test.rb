require 'test_helper'

class SalescountTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
