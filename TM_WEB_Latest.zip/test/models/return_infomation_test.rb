require 'test_helper'

class ReturnInfomationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
