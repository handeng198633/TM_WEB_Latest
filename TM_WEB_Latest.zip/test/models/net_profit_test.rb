require 'test_helper'

class NetProfitTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
