require 'test_helper'

class TrainticketTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
