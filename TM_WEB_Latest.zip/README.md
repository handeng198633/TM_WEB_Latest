== README

Personal web, Use : Rails + Datatable + Jquery + BootStrap + Simple_Calendar

Please feel free to use a different markup language if you do not plan to run
<tt>rake doc:app</tt>.
