class Salescount < ActiveRecord::Base
end
