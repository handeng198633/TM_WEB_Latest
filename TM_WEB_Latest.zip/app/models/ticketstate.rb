class Ticketstate < ActiveRecord::Base

end
