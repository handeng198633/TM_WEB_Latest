class Planestate < ActiveRecord::Base
end
