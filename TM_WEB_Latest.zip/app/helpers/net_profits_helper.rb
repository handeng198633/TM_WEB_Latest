module NetProfitsHelper
end
