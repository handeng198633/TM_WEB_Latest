class TravelinfosController < ApplicationController
  def index
  end

  def new
  end
end
