class ReturninfosController < ApplicationController
  def index
  end

  def new
  end
end
